﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace ExemploAnnotation
{
    class Program
    {
        private static IEnumerable<PropertyInfo> GetPropriedadesInt(object obj)
        {
            var type = obj.GetType();
            var propriedades = type.GetProperties();

            return propriedades.Where(x => x.PropertyType == typeof(int));
        }

        static void Main(string[] args)
        {
            var modelo = new ExemploModel
            {
                Numero1 = 20,
                Numero2 = 30,
                Numero3 = 40,
                Nome = "João"
            };

            // Buscar propriedades 'int' do objeto
            var atributosInt = GetPropriedadesInt(modelo);

            // Pegar os atributos que contem a annotation 'Exemplo'
            var atributosComAnnotation = atributosInt.Where(x => x.GetCustomAttributes(typeof(ExemploAttribute), false).Length > 0);

            // Somar os atributos 'int' com a annotation 'Exemplo'
            var soma = atributosComAnnotation.Sum(x => (int)x.GetValue(modelo));
        }
    }
}
