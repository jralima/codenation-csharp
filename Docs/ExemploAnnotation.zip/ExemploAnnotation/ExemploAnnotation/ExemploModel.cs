﻿namespace ExemploAnnotation
{
    public class ExemploModel
    {
        [Exemplo]
        public int Numero1 { get; set; }

        public int Numero2 { get; set; }

        [Exemplo]
        public int Numero3 { get; set; }

        public string Nome { get; set; }
    }
}
