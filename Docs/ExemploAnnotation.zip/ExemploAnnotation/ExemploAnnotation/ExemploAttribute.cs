﻿using System;

namespace ExemploAnnotation
{
    [AttributeUsage(AttributeTargets.All)]
    public class ExemploAttribute: Attribute
    {
    }
}
